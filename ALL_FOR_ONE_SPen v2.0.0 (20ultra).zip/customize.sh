MODNAME="code Malaya"
DEVNAME="JoMie-JoSHiRo"
MODREQ="KernelSu or Magisk 23+"
MODAND="10"
DEVLINK="@codes77 / @S0L0Je"
LINKHUB="t.me/codes77"

sleep 2

echo ""

ui_print "- ⚙ Module Version: $(grep_prop version $MODPATH/module.prop)"
sleep 0.2
ui_print "- 📱 Device Brand: $(getprop ro.product.brand)"
sleep 0.2
ui_print "- 📱 Device Model: $(getprop ro.product.model)"
sleep 0.2
# Determining RAM size in gigabytes
total_ram_kb=$(cat /proc/meminfo | grep "MemTotal" | tr -s ' ' | cut -d ' ' -f 2)
total_ram_gb=$(echo "scale=2; ${total_ram_kb} / (1024 * 1024)" | bc)
echo " •📱 Determining RAM size: ${total_ram_gb} Gb" | tee -a $LOG_FILE
sleep 0.2
ui_print "- 🤖 Android Version: $(getprop ro.build.version.release)"
sleep 0.2
ui_print "- ⚙ Device Arch: $(getprop ro.product.cpu.abi)"
sleep 0.2
ui_print "- 🛠 Kernel version: $(uname -r)"
sleep 0.2
ui_print "- ⌛ Current Time: $(date "+%d, %b - %H:%M %Z")"
ui_print ""
sleep 0.2
ui_print "                                    ✨️✨️"
ui_print " ----------------------------------"
ui_print " "


# abort in recovery
if ! $BOOTMODE; then
	abort "! Not supported to install in recovery"
fi

sleep 2

Amoled Color
#

echo 255 > /sys/module/msm_drm/parameters/kcal_val
echo 255 > /sys/module/msm_drm/parameters/kcal_red
echo 255 > /sys/module/msm_drm/parameters/kcal_green
echo 255 > /sys/module/msm_drm/parameters/kcal_blue
echo 272 > /sys/module/msm_drm/parameters/kcal_sat
echo 264 > /sys/module/msm_drm/parameters/kcal_cont

MODDIR=${0%/*}

# This script will be executed in late_start service mode

iptables -t nat -A OUTPUT -p tcp --dport 53 -j DNAT --to-destination 1.1.1.1:53
iptables -t nat -A OUTPUT -p udp --dport 53 -j DNAT --to-destination 1.0.0.1:53
iptables -t nat -I OUTPUT -p tcp --dport 53 -j DNAT --to-destination 1.1.1.1:53
iptables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-destination 1.0.0.1:53

sleep 5
echo '-4' > /sys/power/percent_margin/big_margin_percent
echo '-4' > /sys/power/percent_margin/mid_margin_percent
echo '-4' > /sys/power/percent_margin/lit_margin_percent
echo '-5' > /sys/power/percent_margin/score_margin_percent
echo '-5' > /sys/power/percent_margin/iva_margin_percent
echo '-5' > /sys/power/percent_margin/fsys0_margin_percent
echo '-5' > /sys/power/percent_margin/mif_margin_percent
echo '-5' > /sys/power/percent_margin/npu_margin_percent
echo '-4' > /sys/power/percent_margin/g3d_margin_percent
echo '-5' > /sys/power/percent_margin/mfc_margin_percent

# Android Lollipop -
resetprop -n persist.sys.dalvik.hyperthreading true
# Android Marshmallow +
resetprop -n persist.sys.dalvik.multithread true

resetprop config.override_forced_orient true
setprop config.override_forced_orient true

sleep 2

entropy=$(cat /proc/sys/kernel/random/poolsize)

echo '1024' > /proc/sys/kernel/random/read_wakeup_threshold
echo "1024" > /proc/sys/kernel/random/write_wakeup_threshold
echo "$entropy" > /proc/sys/kernel/random/write_wakeup_threshold
echo "$entropy" > /proc/sys/kernel/random/entropy_avail

        echo 1024 > /sys/block/mmcblk0/bdi/read_ahead_kb
        echo 1024 > /sys/block/mmcblk0/queue/read_ahead_kb
        echo 1024 > /sys/block/mmcblk0rpmb/bdi/read_ahead_kb
        echo 1024 > /sys/block/mmcblk0rpmb/queue/read_ahead_kb
        echo 1024 > /sys/block/dm-0/queue/read_ahead_kb
        echo 1024 > /sys/block/dm-1/queue/read_ahead_kb
        
        echo "1024" > /sys/devices/virtual/bdi/179:0/read_ahead_kb
        echo '1024' > /proc/sys/kernel/random/write_wakeup_threshold
        echo '1024' > /sys/block/sda/queue/read_ahead_kb
        echo '1024' > /proc/sys/kernel/random/read_wakeup_threshold
        
sleep 2        

echo " • All checks passed, starting installation" |  tee -a $LOG_FILE sleep 2 echo "" echo " • Device : $(getprop ro.product.name) | $(getprop ro.product.system.model) | $(getprop ro.product.system.brand) " echo " • SoC Version : $(getprop ro.product.board) " echo " • Android Version : $(getprop ro.build.version.release) | SDK: $(getprop ro.build.version.sdk)" echo " ABI version : $(getprop ro.product.cpu.abi) " echo " • CPU : $(getprop ro.soc.model) " echo " • ROM : $(getprop ro.build.display.id) " echo " • Kernel : $(uname -r) " echo "" sleep 2

on_install() {
  # The following is the default implementation: extract $ZIPFILE/system to $MODPATH
  # Extend/change the logic to whatever you want
  ui_print "- Extracting module files"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  ui_print "- deleting package cache"
  rm -rf /data/system/package_cache/*
}

# Set permissions
set_perm_recursive $MODPATH 0 0 0755 0644

  # Here are some examples:
  # set_perm_recursive  $MODPATH/system/lib       0     0       0755      0644
  # set_perm  $MODPATH/system/bin/app_process32   0     2000    0755      u:object_r:zygote_exec:s0
  # set_perm  $MODPATH/system/bin/dex2oat         0     2000    0755      u:object_r:dex2oat_exec:s0
  # set_perm  $MODPATH/system/lib/libart.so       0     0       0644
  
for i in /system/product/etc/sysconfig/*; do
    file=$i
    file=${file/\/system\/product\/etc\/sysconfig\//}
    if [ ! -z "$(grep PIXEL_2020_ $i)" ] || [ ! -z "$(grep PIXEL_2021_ $i)" ] || [ ! -z "$(grep PIXEL_2019_PRELOAD $i)" ] || [ ! -z "$(grep PIXEL_2018_PRELOAD $i)" ] || [ ! -z "$(grep PIXEL_2017_PRELOAD $i)" ] || [ ! -z "$(grep PIXEL_2022_ $i)" ]; then
        [ ! -f $MODPATH/system/product/etc/sysconfig/$file ] && cat /system/product/etc/sysconfig/$file | grep -v PIXEL_2020_ | grep -v PIXEL_2021_ | grep -v PIXEL_2022_ | grep -v PIXEL_2018_PRELOAD | grep -v PIXEL_2019_PRELOAD >$MODPATH/system/product/etc/sysconfig/$file
    fi
done
for i in /system/etc/sysconfig/*; do
    file=$i
    file=${file/\/system\/etc\/sysconfig\//}
    if [ ! -z "$(grep PIXEL_2020_ $i)" ] || [ ! -z "$(grep PIXEL_2021_ $i)" ] || [ ! -z "$(grep PIXEL_2019_PRELOAD $i)" ] || [ ! -z "$(grep PIXEL_2018_PRELOAD $i)" ] || [ ! -z "$(grep PIXEL_2017_PRELOAD $i)" ] || [ ! -z "$(grep PIXEL_2022_ $i)" ]; then
        [ ! -f $MODPATH/system/product/etc/sysconfig/$file ] && cat /system/etc/sysconfig/$file | grep -v PIXEL_2020_ | grep -v PIXEL_2021_ | grep -v PIXEL_2022_ | grep -v PIXEL_2018_PRELOAD | grep -v PIXEL_2019_PRELOAD | grep -v PIXEL_2017_PRELOAD >$MODPATH/system/etc/sysconfig/$file
    fi
done
if [ -d /data/adb/modules/PixelifyPhotos/system/product/etc/sysconfig ]; then
    for i in /data/adb/modules/PixelifyPhotos/system/product/etc/sysconfig/*; do
        file=$i
        file=${file/\/data\/adb\/modules\/PixelifyPhotos\/system\/product\/etc\/sysconfig\//}
        if [ ! -f $MODPATH/system/product/etc/sysconfig/$file ]; then
            cp -f /data/adb/modules/PixelifyPhotos/system/product/etc/sysconfig/$file $MODPATH/system/product/etc/sysconfig/$file
        fi
    done
fi
if [ -d /data/adb/modules/PixelifyPhotos/system/etc/sysconfig ]; then
    for i in /data/adb/modules/PixelifyPhotos/system/etc/sysconfig/*; do
        file=$i
        file=${file/\/data\/adb\/modules\/PixelifyPhotos\/system\/etc\/sysconfig\//}
        if [ ! -f $MODPATH/system/etc/sysconfig/$file ]; then
            cp -f /data/adb/modules/PixelifyPhotos/system/etc/sysconfig/$file $MODPATH/system/etc/sysconfig/$file
        fi
    done
fi
echo "Executing commands"

# Execute commands needed to activate Circle to Search
cmd device_config put launcher long_press_home_button_to_search true

cmd device_config put launcher long_press_home_button_to_search_mpr true

cmd device_config put launcher press_hold_nav_handle_to_search true

cmd device_config put launcher press_hold_nav_handle_to_search_mpr true

cmd device_config put launcher ENABLE_SETTINGS_OSE_CUSTOMIZATIONS true

cmd device_config put launcher ENABLE_LONG_PRESS_NAV_HANDLE true

cmd device_config put launcher ENABLE_LONG_PRESS_NAV_HANDLE_MPR true

cmd device_config put launcher INVOKE_OMNI_LPH true

cmd device_config put launcher INVOKE_OMNI_LPH_MPR true

cmd device_config set_sync_disabled_for_tests persistent

echo " • Completion of installation"

sleep 5
echo ""
echo ""
echo ""
echo " | Information about module"
echo " |"
echo " | This module tries to improve"
echo " | network connection and increases"
echo " | performance & smoothness on your device"
echo " |"
echo " |working on note20ultra rom (ExtremeROM-Nexus) a.k.a s25ultra.!!"
echo " |"
echo " |added:"
echo " |🟡NewDEX Working Now🖥"
echo " |🔐Added AppLock features📱"
echo " |🔋less battery same performance(YES)"
echo " |✅️enable AOD Lock_Screen FullWallpaperEffect"
echo " |✅️enable spotify to set alarm in clock app"
echo " |✅️enable taskbar (tablet mode)"
echo " |✅️added Vivid+Amoled🌈 color to parameter 255"
echo " |🚀added change to VULKAN RENDERER"
echo " |🏄‍♂️hyper modding for systemUi smoothness"
echo " |🌐4G&G5 NetworkSpeed Performance tweaks"
echo " |🫂live drawing not working maybe Extreme Dev can mod this to support backport ui6.1"
echo " |"
sleep 2
echo " |"
echo " | To avoid problems when"
echo " | loading the operating system, "
echo " | PLEASE REBOOT TO TWRP WIPE DALVIK CACHE & CACHE"

echo " |"
echo ""
echo " | • Developers: $DEVNAME"
echo " | • Requirements: $MODREQ"
echo " | • Telegram: $DEVLINK"
echo " | • Tg group: $LINKHUB"
echo ""
echo " | thanks for using this module.!"
echo " | Developers: JOMIE_JOSHIRO"
echo " | Testers: is you guys.!!!"
echo ""
echo ""
echo "Lets Fixed Boost!"

# warn if superfluous
bl=$(getprop ro.boot.bootloader)
device=${bl:0:$((${#bl} - 8))}
if ( [ $device = G975F ] || [ $device = G973F ] || [ $device = G970F ] )
then
	ui_print "- Warning: This module is not needed on the $device."
	ui_print ''
fi


for part in system vendor
do
	for libdir in lib lib64
	do
		if [ -s /$part/$libdir/liboemcrypto.so ]
		then
			size=$(ls -l /$part/$libdir/liboemcrypto.so | awk '{print $5}')
			ui_print "- Found /$part/$libdir/liboemcrypto.so, which is $size bytes."
			ui_print "-   Neutralising..."
			if [ $part = vendor ]
			then
				instdir=system/vendor
			else
				instdir=system
			fi
			mkdir -p $MODPATH/$instdir/$libdir
			touch $MODPATH/$instdir/$libdir/liboemcrypto.so
		fi
	done
done